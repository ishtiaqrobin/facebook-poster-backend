import os
import sys

# Add your project directory to the sys.path
INTERP = os.path.expanduser("/home/ezbitlyc/virtualenv/facebook-poster-backend.ezbitly.com/3.11/bin/python")
if sys.executable != INTERP:
    os.execl(INTERP, INTERP, *sys.argv)

# Set the Django settings module path
os.environ['DJANGO_SETTINGS_MODULE'] = 'backend.settings'

# Add the project directory to the Python path
sys.path.insert(0, os.path.dirname(__file__))

# Import Django's WSGI application
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
